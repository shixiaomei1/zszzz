
$(function(){
	$("[name=jk]").each(function(i){
		$(this).mouseenter(function(){
			$("[name=jk]").attr("class","a3_no")
			$(this).attr("class","a3_yes")
			$("[class^=jh_]").hide();
			$(".jh_"+(i+1)).show();
			if(i==0) $("[class^=jh_]").show();
		})
	})	
})
